"use strict"

/* Tiffany Noel Author Website

Author: Hannah Thacker
Date: 02/03/2025

Filename: slideIMG.js
*/

showImage();
setInterval("showImage()", 5000);

function showImage() {
    for (var i = 0; i < imgArray.length; i++) {
        
    }
}

var imgArray = new Array(4)
imgArray[0] = "CoverReveal1.jpeg";
imgArray[1] = "CoverReveal2.jpeg";
imgArray[2] = "pottery.jpg";
imgArray[3] = "couple.jpg";