"use strict"

/* Tiffany Noel Author Website

Author: Hannah Thacker
Date: 02/03/2025

Filename: slideIMG.js
*/
var slide = 1;
var imgArray = new Array(4)
imgArray[0] = "CoverReveal1.jpeg";
imgArray[1] = "CoverReveal2.jpeg";
imgArray[2] = "pottery.jpg";
imgArray[3] = "couple.jpg";
setInterval(showImage, 10000);

function showImage() {
    //for (var i = 0; i < imgArray.length; i++) {
    if(slide < 4){
        document.getElementById("slideImage").src = imgArray[slide];
      //document.getElementById("slide").innerHTML = "<img src=" + imgArray[slide] + " />"; 
    } else {
        slide = 0;
        document.getElementById("slideImage").src = imgArray[slide];
    }
    slide++;
}
