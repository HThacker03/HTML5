"use strict";

/*
   New Perspectives on HTML5 and CSS3, 8th Edition
   Tutorial 10
   Case Problem 1

   Author: Hannah Thacker
   Date: 01/30/2025
   
   Filename: tc_cart.js
	
*/

var orderTotal = 0;
var cartHTML = "<table>" +
                "<tr>" + 
                "<th>Item</th><th>Description</th><th>Price</th><th>Qty</th><th>Total</th>" + 
                "</tr>";

for (var i = 0; i < item.length; i++) {
    cartHTML += "<tr><td><img='tc_item.png' alt='" + item[i] + "' /></td>";
    cartHTML += "<td>" + itemDescription[i] + 
                "</td><td>$" + itemPrice[i] + 
                "</td><td>" + itemQty[i] + "</td>";
}
