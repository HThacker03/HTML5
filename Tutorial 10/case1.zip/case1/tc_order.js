"use strict";

/*
   New Perspectives on HTML5 and CSS3, 8th Edition
   Tutorial 10
   Case Problem 1
  
   Author: Hannah Thacker
   Date: 01/30/2025
     
   Filename: tc_order.js  

   The item array contains the ID numbers of the items ordered by the customer
   The itemDescription array contains the description of each item
   The itemPrice array contains the price of each item
   The itemQty array contains the quantity ordered of each item
   
*/

var item = [];
item[0] = 10582;
item[1] = 23015;
item[2] = 41807;
item[3] = 10041;

var itemDescription = [];
itemDescription[0] = "1975 Green Bay Packers Football (signed), Item 10582";
itemDescription[1] = "Tom Landry 1955 Football Card (unsigned), Item 23015";
itemDescription[2] = "1916 Army-Navy Game, Framed Photo (signed), Item 41807";
itemDescription[3] = "Protective Card Sheets, Item 10041";

var itemPrice = [];
itemPrice[0] = 149.93;
itemPrice[1] = 89.98;
itemPrice[2] = 334.93;
itemPrice[3] = 22.67;

var itemQty = [];
itemQty[0] = 1;
itemQty[1] = 1;
itemQty[2] = 1;
itemQty[3] = 4;