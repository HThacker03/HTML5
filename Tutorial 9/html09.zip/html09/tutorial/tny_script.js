/*
   New Perspectives on HTML5 and CSS3, 8th Edition
   Tutorial 9
   Tutorial Case

   Countdown Clock
   Author: Hannah Thacker
   Date: 01/24/2025

*/

window.alert("Welcome to Tulsa");

